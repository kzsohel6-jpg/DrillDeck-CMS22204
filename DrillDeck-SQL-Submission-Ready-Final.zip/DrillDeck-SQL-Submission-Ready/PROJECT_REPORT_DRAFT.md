# DrillDeck Project Report

**Project title:** DrillDeck: A Full-Stack Interactive Scenario Training and Decision Scoring Platform  
**Student:** Kamruzzaman Sohel  
**Target audience:** Trainees, trainers and administrators in organisations that need practical decision-based learning.

## 1. Project Summary and Problem Statement

DrillDeck is a full-stack web application that replaces passive training quizzes with realistic, multi-step decision scenarios. Many training systems test whether a learner remembers information, but they do not show how that learner responds when several actions appear reasonable. DrillDeck presents workplace safety, cybersecurity, privacy, crowd management, emergency response and business continuity situations. Trainees choose actions, receive immediate coaching and obtain a stored performance result. Trainers use a separate administrator area to manage content and review learning analytics. The platform therefore supports practical learning, measurable progression and evidence-based training decisions.

## 2. Core Features and User Stories

The application provides secure registration and login with role-based access for trainees and administrators. A trainee can search, filter and sort a twelve-scenario library, select Easy, Medium or Hard mode, complete five decisions and review detailed feedback. Every decision contains four realistic alternatives, while answer positions are balanced and randomised to avoid predictable patterns. Completed attempts are stored in SQL and displayed through personal history, category performance, experience points and progress indicators. An administrator can create, edit, publish and delete scenarios with nested questions, choices, scores, feedback, artwork, learning outcomes and skill tags. The administrator dashboard reports users, attempts, average scores, content balance and scenario performance.

## 3. Technical Stack

React and Vite provide the responsive frontend, reusable components and client-side routing. Context API stores authentication state, Axios communicates with the backend and Recharts presents analytics. Node.js and Express provide RESTful API endpoints and business logic. SQLite was selected as a portable relational SQL database, while Sequelize defines models, relationships, validation and queries. JWT protects authenticated routes and bcrypt hashes passwords. Local SVG artwork and responsive CSS create a consistent visual identity without relying on external image services.

## 4. System Architecture and Process Logic

The React client sends JSON requests to the Express API. Authentication returns a JWT, which is stored locally and included in protected requests. Sequelize reads and writes Users, Scenarios, Steps, Choices, Attempts and AttemptAnswers in SQLite. When a trainee submits an attempt, the backend validates every choice against its parent step and calculates the result from database scores rather than trusting the browser. The response includes percentage, outcome, experience points and a decision review. Dashboard endpoints aggregate attempt data for trainee and administrator charts.

## 5. Challenges and Ethical Considerations

Key challenges included designing nested relational data, protecting role-specific routes, preventing predictable answer patterns and keeping the application achievable within the project period. Testing covers authentication, CRUD operations, SQL persistence, validation, scoring, filtering, responsive layout and error handling. Passwords are never stored as plain text, and API responses do not expose them. Scenario feedback is educational rather than professional certification, so future development could include expert-reviewed content, accessibility testing, automated API tests and cloud deployment.
