# 10-Minute DrillDeck Presentation Guide

## 0:00–1:00 — Problem and concept

Explain that many training systems test memory rather than judgement. DrillDeck presents realistic multi-step situations, scores decisions and stores measurable performance.

## 1:00–2:00 — Full-stack architecture

Show the React frontend, Express REST API, JWT authentication, Sequelize ORM and SQLite relational database. Briefly explain the User, Scenario, Step, Choice, Attempt and AttemptAnswer relationships.

## 2:00–3:00 — Trainee dashboard

Sign in as the trainee. Show XP, level, progress, recommended scenario, three colour-coded training modes and category analytics.

## 3:00–4:00 — Complete scenario library

Show all 12 illustrated scenarios. Use search, category filtering, difficulty filtering and sorting. Emphasise 4 Easy, 4 Medium, 4 Hard, 60 decisions and 240 scored choices.

## 4:00–6:00 — Complete a scenario

Open one Hard scenario. Show artwork, skills, progress and four realistic choices. Point out that the highest-scoring answer positions are balanced in the data and the interface randomises option order for each session. Select decisions and explain that scores are hidden from the trainee payload and the coaching is returned securely by the backend after each choice.

## 6:00–7:00 — Result and SQL history

Complete the scenario. Show percentage, result level, XP and expandable decision reviews. Open attempt history, select Answers, and explain that the score plus every selected response persists in SQLite after logout and restart.

## 7:00–8:30 — Administrator experience

Sign in as administrator. Show content totals, difficulty distribution, performance chart and recent activity. Open the scenario studio and show nested steps, 4–8 choices, scores, feedback, artwork, learning outcomes and publication status. Then open Trainee records and show one learner’s saved decision-level answers.

## 8:30–9:30 — Security and quality

Discuss bcrypt password hashing, JWT, protected routes, role-based access, server-side scoring, validation, SQL transactions, responsive design and the static verification and the automated live integration check.

## 9:30–10:00 — Evaluation and future work

Summarise how DrillDeck meets the brief: React, Node.js, SQL, authentication, role access, search/filter/sort, dashboard/reporting, CRUD, documentation and testing. Mention cloud deployment, accessibility audits and expert-reviewed scenario packs as future development.
